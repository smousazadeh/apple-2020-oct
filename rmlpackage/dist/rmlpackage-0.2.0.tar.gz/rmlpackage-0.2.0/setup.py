# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['rmlpackage']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'rmlpackage',
    'version': '0.2.0',
    'description': 'Another amazing package that does nothing!',
    'long_description': None,
    'author': 'Reuven Lerner',
    'author_email': 'reuven@lerner.co.il',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
